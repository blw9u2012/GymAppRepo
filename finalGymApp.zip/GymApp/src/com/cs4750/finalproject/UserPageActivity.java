package com.cs4750.finalproject;

import android.app.Activity;
import android.os.Bundle;

public class UserPageActivity extends Activity{

	@Override
	public void onCreate(Bundle savedInstanceState){
		super.onCreate(savedInstanceState);
		setContentView(R.layout.home_tab);
	}
}
